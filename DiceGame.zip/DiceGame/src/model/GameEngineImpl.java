package model;

import java.util.Collection;
import java.util.Collections;

import model.interfaces.DicePair;
import model.interfaces.GameEngine;
import model.interfaces.GameEngineCallback;
import model.interfaces.Player;

import java.util.ArrayList;

public class GameEngineImpl implements GameEngine {
	
	ArrayList<Player> players = new ArrayList<Player>();
	ArrayList<GameEngineCallback> gameEngineCallbacks = new ArrayList<GameEngineCallback>();
	
	private Player currentPlayer;

	@Override
	public boolean placeBet(Player player, int bet) {
	
		if(player.placeBet(bet) == true) {
			return true;
		}	
		return false;
	}
	
	private void roll(Player player, int initialDelay, int finalDelay, int delayIncrement) {
		
		int dice1 = 0;
		int dice2 = 0;
		int numFaces = NUM_FACES;
	
		DicePair result;
		
		/*get intermediate dice results */
	 while(initialDelay < finalDelay) {
			
			dice1 = (int) ((Math.random() * NUM_FACES) + 1);
			dice2 = (int) ((Math.random() * NUM_FACES) + 1);
			
			result = new DicePairImpl(dice1, dice2, numFaces);
		
			try {
				Thread.sleep(initialDelay);
			} catch (InterruptedException e) {
				
				System.out.println(e.getMessage());
			}
			initialDelay += delayIncrement;
			
			if(player != null) {
				for(GameEngineCallback gameEngineCallback : gameEngineCallbacks) {
					gameEngineCallback.intermediateResult(player, result, this);
				}
			}
			else {
				for(GameEngineCallback gameEngineCallback : gameEngineCallbacks) {
					gameEngineCallback.intermediateHouseResult(result, this);
				}
			}
		}			
	
	 /** create delay between last intermediate result and final result*/
	 try {
		Thread.sleep(delayIncrement);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
		/* get final dice result */
		dice1 = (int) ((Math.random() * NUM_FACES) + 1);
		dice2 = (int) ((Math.random() * NUM_FACES) + 1);
		
		result = new DicePairImpl(dice1, dice2, numFaces);
		
		
			if(player != null) {
				for(GameEngineCallback gameEngineCallback : gameEngineCallbacks) {				
					gameEngineCallback.result(player, result, this);	
					player.setRollResult(result);
				}
			}
			else {	
				int houseTotal = dice1 + dice2;
				updateBetPoints(houseTotal);
				for(GameEngineCallback gameEngineCallback : gameEngineCallbacks) {					
					gameEngineCallback.houseResult(result, this);
				}
			}
			
			/*for(Player simplePlayer: getAllPlayers()) {
				simplePlayer.placeBet(0);
				//player.setRollResult(null);
			}*/
			
		}
	

	@Override
	public void rollPlayer(Player player, int initialDelay, int finalDelay, int delayIncrement) {
	
		roll(player, initialDelay,  finalDelay,  delayIncrement);
	}
	
	@Override
	public void rollHouse(int initialDelay, int finalDelay, int delayIncrement) {
		
		roll(null, initialDelay,  finalDelay,  delayIncrement);
	
	}
	
	private void updateBetPoints(int houseDiceTotal) {
		
		int points = 0;	
	
		//iterate through players and apply win or loss
		for (Player player : players) {
			
			if(player.getBet() != 0 && player.getRollResult() != null) {
			
				// player lost against house
				if(player.getRollResult().getDice1() + player.getRollResult().getDice2() < houseDiceTotal){ 
					points = player.getPoints() - player.getBet();			
				}
				// player won against house
				else if(player.getRollResult().getDice1() + player.getRollResult().getDice2()  > houseDiceTotal) {  
					points = player.getPoints() + player.getBet();		
				}
				//player drew with house
				else if(player.getRollResult().getDice1() + player.getRollResult().getDice2()  == houseDiceTotal) { 
					points = player.getPoints();
				}
				player.setPoints(points);
			
			}			
		}	
	}
	
	@Override
	public void addPlayer(Player player) {
		currentPlayer = player;	
		players.add(player);
	}

	@Override
	public Player getPlayer(String id) {
		if(id != null) {
			return currentPlayer;
		}	
		return null;	
	}

	@Override
	public boolean removePlayer(Player player) {
		if(player != null) {
			players.remove(player);
			return true;
		}
		return false;
	}

	@Override
	public void addGameEngineCallback(GameEngineCallback gameEngineCallback) {
		gameEngineCallbacks.add(gameEngineCallback);
	}

	@Override
	public boolean removeGameEngineCallback(GameEngineCallback gameEngineCallback) {
		if(gameEngineCallback != null) {
			gameEngineCallbacks.remove(gameEngineCallback);
			return true;
		}
		return false;
	}

	@Override
	public Collection<Player> getAllPlayers() {
		Collection<Player> unmodifiablePlayers = Collections.unmodifiableCollection(players);
		return unmodifiablePlayers;  
	}

}
