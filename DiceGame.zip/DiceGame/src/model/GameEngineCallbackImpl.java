package model;

import java.util.logging.Level;
import java.util.logging.Logger; 

import model.interfaces.DicePair;
import model.interfaces.GameEngine;
import model.interfaces.GameEngineCallback;
import model.interfaces.Player;

/**
 * 
 * Skeleton example implementation of GameEngineCallback showing Java logging behaviour
 * 
 * @author Caspar Ryan
 * @see model.interfaces.GameEngineCallback
 * 
 */


public class GameEngineCallbackImpl implements GameEngineCallback
{
	
	private Logger logger = Logger.getLogger("assignment1");

	public GameEngineCallbackImpl()
	{
		// FINE shows rolling output, INFO only shows result
		logger.setLevel(Level.FINE);	
	}

	@Override
	public void intermediateResult(Player player, DicePair dicePair, GameEngine gameEngine)
	{
		// intermediate results for rolling player dice logged at Level.FINE		
		logger.log(Level.FINE, player.getPlayerName() + ": ROLLING " + dicePair.toString());
	}

	@Override
	public void result(Player player, DicePair result, GameEngine gameEngine)
	{
		// final results for player dice logged at Level.INFO
		logger.log(Level.INFO, player.getPlayerName() + ": *RESULT* " + result.toString());	
	}

	public void intermediateHouseResult(DicePair dicePair, GameEngine gameEngine) {
		// intermediate results for rolling house dice logged at Level.FINE
		logger.log(Level.FINE, " House: ROLLING " + dicePair.toString());
	}
	
	public void houseResult(DicePair result, GameEngine gameEngine) {
		// final results for house dice logged at Level.INFO
		logger.log(Level.INFO, " House: *RESULT* " + result.toString());
		
		playerInfo(gameEngine);
	}

	/* log player's info after points have been updated */
	private void playerInfo(GameEngine gameEngine) {
		for (Player player : gameEngine.getAllPlayers()) {
			logger.log(Level.INFO, player.toString());	
		}
	}

}
