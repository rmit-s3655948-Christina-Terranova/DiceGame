package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.MainFrame;

public class PlaceBetListener implements ActionListener {

	private MainFrame frame;
	private GameEngine game;

	public PlaceBetListener(GameEngine game, MainFrame frame) {
		this.frame = frame;
		this.game = game;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		try {

			/* check if player already placed bet or has rolled */
			for (Player player : game.getAllPlayers()) {
				if (player.getPlayerName().equals(frame.getToolbar().getComboBox().getSelectedItem())) {
					if (player.getRollResult() != null || player.getBet() != 0) {
						JOptionPane.showMessageDialog(frame, "Player already placed bet");
						return;
					}
				}
			}
			/* check if player selected */
			if (frame.getToolbar().getComboBox().getSelectedItem() == null) {
				JOptionPane.showMessageDialog(frame, "Please select a player before placing bet");
			} else {
				for (Player player : game.getAllPlayers()) {
					if (player.getPlayerName().equals(frame.getToolbar().getComboBox().getSelectedItem())) {
						/* check if bet is greater or equal to initial points */
						if (Integer.parseInt(frame.getPlaceBetPanel().getBetTextField().getText()) <= 0 || Integer
								.parseInt(frame.getPlaceBetPanel().getBetTextField().getText()) > player.getPoints()) {
							JOptionPane.showMessageDialog(frame,
									"Bet must be greater than 0 and less than initial points");
						} else {
							game.placeBet(player,
									Integer.parseInt(frame.getPlaceBetPanel().getBetTextField().getText()));
							JOptionPane.showMessageDialog(frame,
									"Bet placed for " + frame.getToolbar().getComboBox().getSelectedItem());
						}

					}
				}
			}

		} catch (NumberFormatException nfe) {
			JOptionPane.showMessageDialog(frame, "Bet must be an integer");
		}

	}

}
