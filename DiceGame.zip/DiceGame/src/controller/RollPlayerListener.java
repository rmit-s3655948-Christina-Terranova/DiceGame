package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.MainFrame;

public class RollPlayerListener implements ActionListener {

	private MainFrame frame;
	private GameEngine game;

	public RollPlayerListener(GameEngine game, MainFrame frame) {
		this.frame = frame;
		this.game = game;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		final int DELAY_INCREMENT = 100;
		final int INITIAL_DELAY = 1;
		final int FINAL_DELAY = 500;

		new Thread() {
			@Override
			public void run() {
				/* check if player selected */
				if (frame.getToolbar().getComboBox().getSelectedItem() == null) {
					JOptionPane.showMessageDialog(frame, "Please select a player before rolling");
				}
				for (Player player : game.getAllPlayers()) {
					/* check that player selected has placed a bet */
					if (player.getPlayerName().equals(frame.getToolbar().getComboBox().getSelectedItem())) {

						if (player.getRollResult() != null) {
							JOptionPane.showMessageDialog(frame, "Player has already rolled");
						} else if (player.getBet() != 0) {

							/* disable buttons while rolling */
							frame.getToolbar().getRollPlayerBtn().setEnabled(false);
							frame.getToolbar().getRollHouseBtn().setEnabled(false);
							frame.getPlaceBetPanel().getBetBtn().setEnabled(false);
							frame.getAddPlayerPanel().getAddPlayerButton().setEnabled(false);

							game.rollPlayer(player, INITIAL_DELAY, FINAL_DELAY, DELAY_INCREMENT);

							/* re-enable buttons after player rolls */
							frame.getToolbar().getRollPlayerBtn().setEnabled(true);
							frame.getToolbar().getRollHouseBtn().setEnabled(true);
							frame.getPlaceBetPanel().getBetBtn().setEnabled(true);
							frame.getAddPlayerPanel().getAddPlayerButton().setEnabled(true);

							/* reset status bar */
							if (!frame.getStatusBarPanel().getPointsLabel().getText().equals("")) {
								frame.getStatusBarPanel().getPointsLabel().setText("");
							}
						} else {
							JOptionPane.showMessageDialog(frame, "Please place a bet for the selected player");
						}
					}
				}
			}
		}.start();
	}
}
