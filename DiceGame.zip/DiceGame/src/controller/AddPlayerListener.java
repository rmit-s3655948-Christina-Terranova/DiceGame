package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import model.SimplePlayer;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.MainFrame;

public class AddPlayerListener implements ActionListener {

	private MainFrame frame;
	private GameEngine game;

	public AddPlayerListener(GameEngine game, MainFrame frame) {
		this.frame = frame;
		this.game = game;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		try {
			/* check for duplicate player name */
			for (Player player : game.getAllPlayers()) {
				if (frame.getAddPlayerPanel().getNameTextField().getText().equals(player.getPlayerName())) {
					JOptionPane.showMessageDialog(frame, "Player already exists- please choose another name");
					return;
				}
			}

			if (frame.getAddPlayerPanel().getIdTextField().getText().equals("")
					|| frame.getAddPlayerPanel().getNameTextField().getText().equals("")
					|| frame.getAddPlayerPanel().getPointsTextField().getText().equals("")) {
				JOptionPane.showMessageDialog(frame, "Please fill in all fields");
			} else if (Integer.parseInt(frame.getAddPlayerPanel().getPointsTextField().getText()) <= 0) {
				JOptionPane.showMessageDialog(frame, "Initial points must be greater than 0");
			} else {
				Player newPlayer = new SimplePlayer(frame.getAddPlayerPanel().getIdTextField().getText(),
						frame.getAddPlayerPanel().getNameTextField().getText(),
						Integer.parseInt(frame.getAddPlayerPanel().getPointsTextField().getText()));
				game.addPlayer(newPlayer);
				frame.getToolbar().getComboBox().addItem(frame.getAddPlayerPanel().getNameTextField().getText());
				JOptionPane.showMessageDialog(frame, frame.getAddPlayerPanel().getNameTextField().getText() + " added");
			}

		} catch (NumberFormatException nfe) {
			/* don't allow non-numeric inputs*/
			JOptionPane.showMessageDialog(frame, "Initial points must be an integer");
		}
	}
}
