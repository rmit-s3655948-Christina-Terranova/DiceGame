package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.MainFrame;

public class RollHouseListener implements ActionListener {

	private MainFrame frame;
	private GameEngine game;

	public RollHouseListener(GameEngine game, MainFrame frame) {
		this.frame = frame;
		this.game = game;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		final int DELAY_INCREMENT = 100;
		final int INITIAL_DELAY = 1;
		final int FINAL_DELAY = 500;

		new Thread() {
			@Override
			public void run() {

				/* check if any player has rolled */
				boolean playerRolled = false;
				for (Player player : game.getAllPlayers()) {
					if (player.getRollResult() != null) {
						playerRolled = true;
						break;
					}
				}

				/* if a player has rolled then allow house to roll */
				if (game.getAllPlayers().isEmpty()) {
					JOptionPane.showMessageDialog(frame, "Please add and roll player first");
				} else if (playerRolled == true) {
					frame.getToolbar().getRollPlayerBtn().setEnabled(false);
					frame.getToolbar().getRollHouseBtn().setEnabled(false);
					frame.getPlaceBetPanel().getBetBtn().setEnabled(false);
					frame.getAddPlayerPanel().getAddPlayerButton().setEnabled(false);
					frame.getToolbar().getComboBox().setEnabled(false);

					game.rollHouse(INITIAL_DELAY, FINAL_DELAY, DELAY_INCREMENT);

					frame.getToolbar().getRollPlayerBtn().setEnabled(true);
					frame.getToolbar().getRollHouseBtn().setEnabled(true);
					frame.getPlaceBetPanel().getBetBtn().setEnabled(true);
					frame.getAddPlayerPanel().getAddPlayerButton().setEnabled(true);
					frame.getToolbar().getComboBox().setEnabled(true);

				} else {
					JOptionPane.showMessageDialog(frame, "Please roll player first");
				}
			}

		}.start();
	}

}
