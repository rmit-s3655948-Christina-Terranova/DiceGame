package client;

import javax.swing.SwingUtilities;

import model.GameEngineCallbackImpl;
import model.GameEngineImpl;
import model.interfaces.GameEngine;
import model.interfaces.GameEngineCallback;
import view.GameEngineCallbackGUI;
import view.MainFrame;

public class MainClient {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				GameEngine game = new GameEngineImpl();
				MainFrame frame = new MainFrame(game);

				GameEngineCallback gameEngineCallbackGUI = new GameEngineCallbackGUI(game, frame);
				GameEngineCallback gameEngineCallback = new GameEngineCallbackImpl();

				game.addGameEngineCallback(gameEngineCallback);
				game.addGameEngineCallback(gameEngineCallbackGUI);

			}
		});
	}
}
