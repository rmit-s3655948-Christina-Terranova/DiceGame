package view;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.PlaceBetListener;
import model.interfaces.GameEngine;

public class PlaceBetPanel extends JPanel {

	private JTextField bet;
	private JButton betBtn;

	public PlaceBetPanel(GameEngine game, MainFrame frame) {

		JLabel betLabel = new JLabel("Enter points to bet: ");
		bet = new JTextField("1000");
		
		betBtn = new JButton("Place bet");
		betBtn.addActionListener(new PlaceBetListener(game, frame));

		setLayout(new GridLayout(4, 1, 10, 10));
		add(betLabel);
		add(bet);
		add(betBtn);

	}

	public JTextField getBetTextField() {
		return bet;
	}

	public JButton getBetBtn() {
		return betBtn;
	}

}
