package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;

import model.interfaces.DicePair;
import model.interfaces.GameEngine;
import model.interfaces.Player;

public class MainFrame extends JFrame {

	private GameEngine game;
	private Toolbar toolbar;
	private PlayerResultPanel playerResultPanel;
	private HouseResultPanel houseResultPanel;
	private StatusBarPanel statusBarPanel;
	private PlaceBetPanel placeBetPanel;
	private AddPlayerPanel addPlayerPanel;
	private PullDownMenu pullDownMenu;

	public MainFrame(GameEngine game) {
		this.game = game;

		setBounds(100, 100, 800, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		/* set font of all labels, buttons and textfields in frame */
		UIManager.put("Label.font", new Font("Arial", 1, 15));
		UIManager.put("Button.font", new Font("Arial", 1, 15));
		UIManager.put("TextField.font", new Font("Arial", 1, 15));

		toolbar = new Toolbar(game, this);
		add(toolbar, BorderLayout.NORTH);

		statusBarPanel = new StatusBarPanel(game, this);
		add(statusBarPanel, BorderLayout.SOUTH);

		pullDownMenu = new PullDownMenu(this);
		add(pullDownMenu);

		JPanel mainPanel = new JPanel(new GridLayout(2, 1, 80, 20));

		addPlayerPanel = new AddPlayerPanel(game, this);
		mainPanel.add(addPlayerPanel);

		placeBetPanel = new PlaceBetPanel(game, this);
		mainPanel.add(placeBetPanel);

		playerResultPanel = new PlayerResultPanel(game, this);
		mainPanel.add(playerResultPanel);

		houseResultPanel = new HouseResultPanel(game, this);
		mainPanel.add(houseResultPanel);

		add(mainPanel);

		/* allows background colour on mainpanel to be visible */
		addPlayerPanel.setOpaque(false);
		playerResultPanel.setOpaque(false);
		houseResultPanel.setOpaque(false);
		placeBetPanel.setOpaque(false);

		mainPanel.setBackground(new Color(1, 109, 41, 190));

		ImageIcon diceIcon = new ImageIcon("diceImages/diceIcon.png");
		setIconImage(diceIcon.getImage());
		setTitle("Dice Game");

		setVisible(true);

	}

	public Toolbar getToolbar() {
		return toolbar;
	}

	public PlayerResultPanel getPlayerResultPanel() {
		return playerResultPanel;
	}

	public HouseResultPanel getHouseResultPanel() {
		return houseResultPanel;
	}

	public StatusBarPanel getStatusBarPanel() {
		return statusBarPanel;
	}

	public PlaceBetPanel getPlaceBetPanel() {
		return placeBetPanel;
	}

	public AddPlayerPanel getAddPlayerPanel() {
		return addPlayerPanel;
	}

	/* displays each intermediate dice roll as it's corresponding dice image */
	private void displayDiceResult(DicePair dicePair, boolean isPlayerResult) {
		String dice1ImgPath = "", dice2ImgPath = "";
		ImageIcon dice1ImageIcon, dice2ImageIcon;

		/* change player dice 1 image */
		dice1ImgPath = "diceImages/dice" + Integer.toString(dicePair.getDice1()) + ".png";
		dice1ImageIcon = new ImageIcon(
				new ImageIcon(dice1ImgPath).getImage().getScaledInstance(42, 42, Image.SCALE_DEFAULT));

		if (isPlayerResult) {
			getPlayerResultPanel().getDice1ImageLabel().setIcon(dice1ImageIcon);
		} else {
			getHouseResultPanel().getDice1ImageLabel().setIcon(dice1ImageIcon);
		}

		/* change player dice 2 image */
		dice2ImgPath = "diceImages/dice" + Integer.toString(dicePair.getDice2()) + ".png";
		dice2ImageIcon = new ImageIcon(
				new ImageIcon(dice2ImgPath).getImage().getScaledInstance(42, 42, Image.SCALE_DEFAULT));

		if (isPlayerResult) {
			getPlayerResultPanel().getDice2ImageLabel().setIcon(dice2ImageIcon);
		} else {
			getHouseResultPanel().getDice2ImageLabel().setIcon(dice2ImageIcon);
		}

		/* display player dice total */
		if (isPlayerResult) {
			getPlayerResultPanel().getDiceTotalText()
					.setText(Integer.toString(dicePair.getDice1() + dicePair.getDice2()));
		} else {
			getHouseResultPanel().getDiceTotalText()
					.setText(Integer.toString(dicePair.getDice1() + dicePair.getDice2()));
		}
	}

	public void displayPlayerDiceResult(DicePair dicePair) {
		displayDiceResult(dicePair, true);
	}

	public void displayHouseDiceResult(DicePair dicePair) {
		displayDiceResult(dicePair, false);
	}

	/* displays players updated points after house rolls */
	public void displayUpdatedPoints() {
		for (Player player : game.getAllPlayers()) {
			// if player has rolled and placed bet
			if (player.getRollResult() != null && player.getBet() != 0) {
				getStatusBarPanel().getPointsLabel()
						.setText(getStatusBarPanel().getPointsLabel().getText() + " " + "Updated points for "
								+ player.getPlayerName() + ": " + Integer.toString(player.getPoints()) + " ");
			}
		}
	}

	/* reset the player bets after house rolls */
	public void resetBets() {
		for (Player player : game.getAllPlayers()) {
			if (player.getBet() != 0 && player.getRollResult() != null) {
				player.placeBet(0);
				player.setRollResult(null);
				getToolbar().getComboBox().removeItem(player.getPlayerName());
			}
		}
	}

}
