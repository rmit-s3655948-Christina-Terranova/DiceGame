package view;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.AddPlayerListener;
import model.interfaces.GameEngine;

public class AddPlayerPanel extends JPanel {

	private JTextField id;
	private JTextField name;
	private JTextField points;
	private JButton addPlayerButton;

	public AddPlayerPanel(GameEngine game, MainFrame frame) {

		JLabel idLabel = new JLabel("Player id: ");
		id = new JTextField("1");

		JLabel nameLabel = new JLabel("Player name: ");
		name = new JTextField("Player 1");

		JLabel pointsLabel = new JLabel("Initial points: ");
		points = new JTextField("1000");

		addPlayerButton = new JButton("Add player");
		addPlayerButton.addActionListener(new AddPlayerListener(game, frame));

		setLayout(new GridLayout(4, 1, 10, 10));
		add(idLabel);
		add(id);
		add(nameLabel);
		add(name);
		add(pointsLabel);
		add(points);
		add(addPlayerButton);
	}

	public JButton getAddPlayerButton() {
		return addPlayerButton;
	}

	public JTextField getIdTextField() {
		return id;
	}

	public JTextField getNameTextField() {
		return name;
	}

	public JTextField getPointsTextField() {
		return points;
	}

}
