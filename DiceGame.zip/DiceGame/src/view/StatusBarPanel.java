package view;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

import model.interfaces.GameEngine;

public class StatusBarPanel extends JPanel {

	private JLabel updatedPoints;

	public StatusBarPanel(GameEngine game, MainFrame frame) {

		updatedPoints = new JLabel(" ");
		setLayout(new BorderLayout());
		setBorder(BorderFactory.createLineBorder(Color.black, 1));
		add(updatedPoints, BorderLayout.SOUTH);
	}

	public JLabel getPointsLabel() {
		return updatedPoints;
	}
}
