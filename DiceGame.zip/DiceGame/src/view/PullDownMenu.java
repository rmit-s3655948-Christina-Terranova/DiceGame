package view;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import controller.ExitMenuListener;

public class PullDownMenu extends JMenuBar {

	public PullDownMenu(MainFrame frame) {
		JMenuBar menuBar = new JMenuBar();
		JMenu menu = new JMenu("File");
		menuBar.add(menu);

		JMenuItem exit = new JMenuItem("Exit");
		exit.addActionListener(new ExitMenuListener());
		menu.add(exit);

		frame.setJMenuBar(menuBar);
	}

}
