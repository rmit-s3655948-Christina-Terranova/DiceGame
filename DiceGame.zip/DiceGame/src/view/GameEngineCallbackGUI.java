package view;

import model.interfaces.DicePair;
import model.interfaces.GameEngine;
import model.interfaces.GameEngineCallback;
import model.interfaces.Player;

public class GameEngineCallbackGUI implements GameEngineCallback {

	private GameEngine game;
	private MainFrame frame;

	public GameEngineCallbackGUI(GameEngine game, MainFrame frame) {
		this.game = game;
		this.frame = frame;
	}

	@Override
	public void intermediateResult(Player player, DicePair dicePair, GameEngine gameEngine) {
		frame.displayPlayerDiceResult(dicePair);
	}

	@Override
	public void result(Player player, DicePair result, GameEngine gameEngine) {
		frame.displayPlayerDiceResult(result);
	}

	@Override
	public void intermediateHouseResult(DicePair dicePair, GameEngine gameEngine) {
		frame.displayHouseDiceResult(dicePair);
	}

	@Override
	public void houseResult(DicePair result, GameEngine gameEngine) {
		frame.displayHouseDiceResult(result);
		frame.displayUpdatedPoints();
		frame.resetBets();
	}

}
