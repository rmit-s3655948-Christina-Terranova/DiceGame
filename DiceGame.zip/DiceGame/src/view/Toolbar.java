package view;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JToolBar;

import controller.RollHouseListener;
import controller.RollPlayerListener;
import model.interfaces.GameEngine;

public class Toolbar extends JToolBar {

	private JComboBox<String> selectPlayer;
	private JButton rollPlayer;
	private JButton rollHouse;

	public Toolbar(GameEngine game, MainFrame frame) {

		rollPlayer = new JButton("Roll player");
		rollPlayer.addActionListener(new RollPlayerListener(game, frame));

		rollHouse = new JButton("Roll house");
		rollHouse.addActionListener(new RollHouseListener(game, frame));

		JLabel selectLabel = new JLabel("Select player: ");
		selectPlayer = new JComboBox<String>();
		selectPlayer.setPrototypeDisplayValue("player 1");

		add(rollPlayer);
		add(rollHouse);
		add(selectLabel);
		add(selectPlayer);
	}

	public JComboBox<String> getComboBox() {
		return selectPlayer;
	}

	public JButton getRollPlayerBtn() {
		return rollPlayer;
	}

	public JButton getRollHouseBtn() {
		return rollHouse;
	}

}
