package view;

import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.interfaces.GameEngine;

public class PlayerResultPanel extends JPanel {

	private JTextField diceTotalText;
	private JLabel dice1ImageLabel;
	private JLabel dice2ImageLabel;

	public PlayerResultPanel(GameEngine game, MainFrame frame) {

		JLabel dice1Label = new JLabel("Player Dice 1: ");
		dice1ImageLabel = new JLabel("");
		ImageIcon dice1ImageIcon = new ImageIcon(
				new ImageIcon("diceImages/dice6.png").getImage().getScaledInstance(42, 42, Image.SCALE_DEFAULT));
		dice1ImageLabel.setIcon(dice1ImageIcon);

		JLabel dice2Label = new JLabel("Player Dice 2: ");
		dice2ImageLabel = new JLabel("");
		ImageIcon dice2ImageIcon = new ImageIcon(
				new ImageIcon("diceImages/dice6.png").getImage().getScaledInstance(42, 42, Image.SCALE_DEFAULT));
		dice2ImageLabel.setIcon(dice2ImageIcon);

		JLabel diceTotalLabel = new JLabel("Player Dice Total: ");
		diceTotalText = new JTextField();
		diceTotalText.setEditable(false);

		setLayout(new GridLayout(4, 2, 0, 5));

		add(dice1Label);
		add(dice1ImageLabel);
		add(dice2Label);
		add(dice2ImageLabel);
		add(diceTotalLabel);
		add(diceTotalText);
	}

	public JTextField getDiceTotalText() {
		return diceTotalText;
	}

	public JLabel getDice1ImageLabel() {
		return dice1ImageLabel;
	}

	public JLabel getDice2ImageLabel() {
		return dice2ImageLabel;
	}

}
